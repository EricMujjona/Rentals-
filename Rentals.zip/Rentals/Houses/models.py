# from django.db import models

# # Create your models here.
# class User(models.Model):
#     username = models.CharField(length=1000)
#     contanct = models.CharField(length=10)
#     password =models.CharField(length=1000)

# class Details(models.Model):
#     # info = models.CharField(length=1000)
#     pass
